BIÇKICI TİCARET - ANDROID STUDIO PROJESİ

Önemli:
Bu ZIP bir APK dosyası değil, APK oluşturmak için Android Studio projesidir.
Bu çalışma ortamında Android SDK/derleme araçları bulunmadığından APK'yı burada derleyip doğrulayamıyorum.

APK oluşturmak için:
1. Bilgisayara Android Studio kurun.
2. Android Studio'da "Open" seçip bu klasörü açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. Derleme bitince çıkan "locate" bağlantısından app-debug.apk dosyasını alın.
6. APK'yı Android telefonunuza gönderip açın. Gerekirse Android ayarlarından bu kaynağa uygulama yükleme izni verin.

Kayıtlar telefonun uygulama içi web depolamasında tutulur. Telefon değişimi veya uygulama verilerini silme durumunda kayıtlar kaybolabilir; ayrıca yedekleme özelliği henüz eklenmemiştir.
